package app.isfaaghyth.moviedb.ui.main;

import app.isfaaghyth.moviedb.base.BaseView;

/**
 * Created by isfaaghyth on 7/24/18.
 * github: @isfaaghyth
 */

interface MainView extends BaseView {

}
