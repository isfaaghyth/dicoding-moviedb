package app.isfaaghyth.moviedb.base;

/**
 * Created by isfaaghyth on 7/26/18.
 * github: @isfaaghyth
 */

public interface BaseView {
    void showLoader();
    void hideLoader();
}
