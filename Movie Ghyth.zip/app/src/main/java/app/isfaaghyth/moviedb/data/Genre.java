package app.isfaaghyth.moviedb.data;

/**
 * Created by isfaaghyth on 7/25/18.
 * github: @isfaaghyth
 */

public class Genre {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
