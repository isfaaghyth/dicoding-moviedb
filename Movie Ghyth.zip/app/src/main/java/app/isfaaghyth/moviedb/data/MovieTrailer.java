package app.isfaaghyth.moviedb.data;

/**
 * Created by isfaaghyth on 7/25/18.
 * github: @isfaaghyth
 */

public class MovieTrailer {
    private String id;
    private String key;
    private int size;
    private String type;

    public String getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public int getSize() {
        return size;
    }

    public String getType() {
        return type;
    }
}
