package app.isfaaghyth.moviedb.data;

import java.util.List;

/**
 * Created by isfaaghyth on 7/24/18.
 * github: @isfaaghyth
 */

public class MovieRepository {
    private List<Movie> results;

    public List<Movie> getResults() {
        return results;
    }
}
