package app.isfaaghyth.moviedb.utils;

import app.isfaaghyth.moviedb.BuildConfig;

/**
 * Created by isfaaghyth on 7/25/18.
 * github: @isfaaghyth
 */

public class Consts {

    public static String loadMovieBanner(String fileName) {
        return BuildConfig.IMG_URL + fileName;
    }

}
