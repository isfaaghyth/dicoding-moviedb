package app.isfaaghyth.moviedb.data;

import java.util.List;

/**
 * Created by isfaaghyth on 7/25/18.
 * github: @isfaaghyth
 */

public class MovieTrailerRepository {
    private List<MovieTrailer> results;

    public List<MovieTrailer> getResults() {
        return results;
    }
}
